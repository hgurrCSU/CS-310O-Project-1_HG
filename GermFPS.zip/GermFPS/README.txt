GITHUB REPO: https://github.com/hgurrCSU/CS-310O-Project-1.git

DEMO VIDEO: https://youtu.be/AEL9dzVYNpQ